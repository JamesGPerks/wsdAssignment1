@javax.xml.bind.annotation.XmlSchema(
    namespace = "http://wsd.com/assignment2",
    elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package wsdassignment2;