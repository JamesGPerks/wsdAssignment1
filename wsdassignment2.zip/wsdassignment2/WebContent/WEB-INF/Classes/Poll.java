package wsdassignment2;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;


@XmlAccessorType(XmlAccessType.FIELD)
public class Poll implements Serializable {
	
	//prevents two IDs created at the same time from having the same value
	static AtomicInteger nextId = new AtomicInteger();
	@XmlAttribute(name = "id")
	private int id;
	@XmlElement(name = "title")
	private String title;
	@XmlElement(name = "user")
	private String user;
	@XmlElement(name = "date")
	private String date;
	@XmlElement(name = "location")
	private String location;
	@XmlElement(name = "description")
	private String description;
	@XmlElement(name = "time")
	private String time;
	@XmlElement(name = "responses")
	private String responses;
	@XmlElement(name = "status")
	private String status;
	
	public Poll() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	//constructor
	public Poll(String title, String user, String date, String location, String description, String time, String status, String responses) {
		super();
		id = nextId.incrementAndGet();
		this.title = title;
		this.user = user;
		this.date = date;
		this.location = location;
		this.description = description;
		this.time = time;
		this.status = status;
		this.responses= responses;
	}

	//getters and setters
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getResponses() {
		return responses;
	}
	
	public void setResponses(String responses) {
		this.responses = responses;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
